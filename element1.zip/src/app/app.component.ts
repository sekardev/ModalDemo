import { Component } from '@angular/core';

@Component({
  selector: 'demo-element',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'element1';
}
