const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/element1/runtime.js',
    './dist/element1/polyfills.js',
    './dist/element1/scripts.js',
    './dist/element1/main.js'
  ];

  await fs.ensureDir('elements');
  await concat(files, 'elements/element1.js');
  await fs.copyFile(
    './dist/element1/styles.css',
    'elements/styles.css'
  );
})();